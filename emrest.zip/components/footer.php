<footer class="text-center py-4 text-gray-500 text-sm border-t border-gray-200 mt-auto">
  © <?= date('Y'); ?> Rumah Sakit Sehat Sentosa. All Rights Reserved.
</footer>
